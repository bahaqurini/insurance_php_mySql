<?php
	define ('dbhost','mysql1002.mochahost.com');
	define ('dbuser','qurini_ad_masaed');
	define ('dbpass','i!C^9@jf*5[m');
	define ('dbname','qurini_insurance');
	define ('psid','a453');
	define ('encpass','sdtgsd');
	
	define ('ENC_KEY','5e6a8c23ab0b4cdf');
	define ('ENC_IV' ,'16fe03a419bce591');
	
?>